#pragma once
#include <iostream>
#include <fstream>
#include "omp.h"
using namespace std;
const long SIZE = 500000;

int fill_array(int array[]);

