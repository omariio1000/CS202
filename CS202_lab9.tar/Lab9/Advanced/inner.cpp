#include "inner.h"

/* This file contains the implementation of the
 * functions for the inner class and its descendents.
 *
 * Author: Mel Flygare <mflygare@pdx.edu>
 * */

unsigned long LLL::sum_data()
{
    return 0;
}

unsigned long LLL::sum_data(LL_node* head)
{
    return 0;
}

unsigned long BST::sum_data()
{
    return 0;
}

unsigned long BST::sum_data(BST_node* root)
{
    return 0;
}

unsigned long LLL::max_data()
{
    return 0;
}

unsigned long LLL::max_data(LL_node* head)
{
    return 0;
}

unsigned long BST::max_data()
{
    return 0;
}

unsigned long BST::max_data(BST_node* root)
{
    return 0;
}

