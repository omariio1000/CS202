#include "outer.h"

/* This file contains the implementation of
 * the functions for the outer class and its
 * descendents.
 *
 * Author: Mel Flygare <mflygare@pdx.edu>
 * */

unsigned long Outer::sum_all()
{
    return 0;
}

unsigned int Outer::max_all()
{
    return 0;
}

double Outer::average_all()
{
    return 0;
}

